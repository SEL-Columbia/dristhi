This folder contains the default view configuration json files as deployed with this Release Version of TB Reach as well as the Shell Script to populate the db with them.
Make sure you have set up couch database on this machine and that couch is accessible via port 5894 (You can modify the script if you use a different port)
Run the command below:

./setup_view_configs.sh <database name>        (e.g.   ./setup_view_configs.sh opensrp_tbreach)

Happy Coding :)
   
